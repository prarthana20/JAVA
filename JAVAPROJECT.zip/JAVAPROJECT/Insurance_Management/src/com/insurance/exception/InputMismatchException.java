package com.insurance.exception;

public class InputMismatchException extends Exception {
	public InputMismatchException(String message) {
		super(message);
		}
}
